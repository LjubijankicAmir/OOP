public class Prvi {
    public static void main(String[] args) {

        System.out.println("Amir Ljubijankic");
    }
}