public class Drugi {

    public static void main(String[] args) {
        System.out.println("Hello world!");
        System.out.println("(And all the people of the world)");
    }
}
