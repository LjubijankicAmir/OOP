public class Treci {
    public static void main(String[] args) {
        System.out.println("There are " + 365*24*60*60 + " seconds in a year");
    }
}
